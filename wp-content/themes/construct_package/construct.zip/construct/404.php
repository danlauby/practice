<?php get_header(); ?>

		<!-- content
				================================================== -->
		<div id="content">

			<!-- error-section 
				================================================== -->
			<section class="error-section">
				<div class="error-content">
					<div class="container">
						<i class="fa fa-thumbs-down"></i>
						<h1>oops! Page not found</h1>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas.</p>
						<a href="javascript:history.back()" class="button-one">Go Back</a>
					</div>
				</div>
			</section>
			<!-- End error section -->
			
		</div>
		<!-- End content -->
<?php get_footer(); ?>